package com.oop.ass3;

public interface Printer {
	void print(Object input);
}
