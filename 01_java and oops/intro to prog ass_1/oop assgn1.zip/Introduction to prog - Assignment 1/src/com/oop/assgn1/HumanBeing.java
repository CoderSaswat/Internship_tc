package com.oop.assgn1;

public interface HumanBeing {
	void walk();

	void speak();

	void run();
}
