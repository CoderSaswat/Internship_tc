package com.oop.assgn1;

public class Alien {
	public void superGammaEnergy() {
		System.out.println("Alien produced gamma energy");
	}

	public void highPowerStrength() {
		System.out.println("Alien attacked with high power strength");
	}

	public void fly() {
		System.out.println("Alien flew away");
	}

	public void invisible() {
		System.out.println("Alien beacome invisible");
	}
}
